<?php
	$servername = "127.0.0.1";
	$username = "root";
	$password = "";
	$basename = "radioemoji";
?>